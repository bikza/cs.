# 13.09.21
from work_1.linear import *
from work_1.forking import *
from work_1.Loop_with_precondition import *
from work_1.Loop_with_postcondition import *
from work_1.Additional_tasks import *
# 21.09.21
from work_2.work_2 import *
from work_2.conditional_operators import *
# 05.10.21
from work_3.work_3 import *


if __name__ == '__main__':
    black_jack()
