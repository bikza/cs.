var num_1 = 5.4; 
var num_2 = 15; 
 
console.log("Результат: " + (num_1 + num_2)); 
 
var num_3 = 5; 
num_3--; 
console.log("Результат: " + num_3); 
 
var str_1 = Number("12"); 
var str_2 = Number("2"); 
console.log("Результат: " + (str_1 + str_2)); 
 
console.log("Math: " + Math.PI); 
console.log("Math: " + Math.max(4, 67, -8, 2, 0, 5, 8)); 